import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import javax.swing.JOptionPane;
import javax.swing.Timer;

/**
 *
 * @author Eren Yildiz
 */
public class MainFrame extends javax.swing.JFrame implements ActionListener, MouseListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1126660785049357211L;

	private int statusCount = 0;

	private int replayState = 0;

	public Random random = new Random();

	private static char[] wordArr;

	private static String[] wordsArr;

	private static String[] tipTexts;

	private static Integer[] counters;

	private static String[] notinwords;

	private static char[] guessResults;

	public static int hangmanCount = 0;

	private static String numGuesses = "";

	public static String word;
	public static String tip;
	public static String notinword;
	public int lastRandomIndex; 
	public static int counter;
	public Boolean scoreSaveState = false;
	public Timer timer;

	/**
	 * Creates new form MainFrame
	 */
	public MainFrame() {
		initComponents();
		statusCount = 1;
		play();
	}

	private void play() {

		word = selectWord();

		System.out.println("Word: " + word);
		
		timer = new Timer(1500, e -> {
			if (counter > 0 && !checkWinState()) {
				counter--;
				repaint();
			} else if (checkWinState()) {

				timer.stop();
			}
			else {
				((Timer) (e.getSource())).stop();
				counter = 0;
				JOptionPane.showMessageDialog(null, "Time is OVER!");

			}
		});
		timer.setInitialDelay(0);

		timer.start();

		wordArr = word.toCharArray();

		guessResults = new char[wordArr.length];

		for (int i = 0; i < guessResults.length; i++) {
			guessResults[i] = '_';
		}
	}

	// generate a random word and return via char array
	public String selectWord() {

		if (replayState == 0) {
			readInputFile();
			int n = wordsArr.length;
			int r = random.nextInt(n);
			lastRandomIndex = r;
			String word = wordsArr[r];
			counter = counters[r]; // set counters and tip accordingly
			tip = tipTexts[r];
			notinword = notinwords[r];

			return word;
		}

		counter = counters[lastRandomIndex];
		return wordsArr[lastRandomIndex];
	}

	public void paint(Graphics g) {
		super.paint(g);

		// set the font
		Font font = new Font("Times New Roman", Font.BOLD | Font.BOLD, 20);
		g.setFont(font);
		g.setColor(Color.BLACK);

		// if user is playing the game
		if (statusCount == 1) {

			String result = "";
			for (int i = 0; i < guessResults.length; i++) {
				result += guessResults[i] + " ";
			}

			g.drawString("GUESSES", 25, 300);
			g.drawString(result, 25, 320);
			g.drawString(numGuesses, 25, 350);
			// if user misses a letter - display body parts
			gameInfo(g);

			hangman(g);
		}
	}

	private void gameInfo(Graphics g) {

		g.setFont(new Font("Arial", Font.PLAIN, 21));

		g.drawString("Tip: " + tip, 25, 80);
		g.drawString("Not in string: " + notinword, 25, 110);
		g.drawString("Countdown: " + counter, 160, 200);

		if (hangmanCount > 6 || counter == 0) {
			g.setColor(Color.RED);
			g.drawString("Status: You LOSE!", 25, 150);
		} else {
			if (!checkWinState() && counter != 0) {
				g.setColor(Color.BLUE);
				g.drawString("Status: PLAYING", 25, 150);
			}

			else if (checkWinState() && hangmanCount < 6) {

				g.setColor(Color.ORANGE);
				g.drawString("Status: WIN", 25, 140);
				if (scoreSaveState == false) {
					scoreSaveState = true;
				}
			}
		}
	}

	public boolean checkWinState() {
		if (Arrays.equals(guessResults, wordArr)) {
			return true;
		}
		else {
			return false;
		}
	}

	/***
	 * 
	 */
	public void readInputFile() {
		// create a bufferedReader
		BufferedReader reader = null;
		// create a list array and store the values from the text file
		List<String> wordList = new ArrayList<String>();
		List<String> tipList = new ArrayList<String>();
		List<String> notinwordList = new ArrayList<String>();
		List<Integer> counterList = new ArrayList<Integer>();

		try {
			reader = new BufferedReader(new FileReader("input.txt"));
			String s = null;

			while ((s = reader.readLine()) != null) {

				s = s.toLowerCase();
				String[] values = s.split(",");
				wordList.add(values[0]);
				tipList.add(values[1]);
				notinwordList.add(values[2]);

				counterList.add(Integer.parseInt(values[3]));

			}

		} catch (IOException e) {

			System.out.println(e.getMessage());
			System.exit(-1);
		} finally {
			try {
				// close the file
				reader.close();
			} catch (IOException e) {
				System.out.println(e.getMessage());
				System.exit(-1);
			}
		}
		// convert from lists to array and assign
		wordsArr = wordList.toArray(new String[wordList.size()]);
		tipTexts = tipList.toArray(new String[tipList.size()]);
		notinwords = notinwordList.toArray(new String[notinwordList.size()]);
		counters = counterList.toArray(new Integer[counterList.size()]);
	}

	private void hangman(Graphics g) {
		Toolkit t = Toolkit.getDefaultToolkit();
		Image i = t.getImage("images/hangman1.png");

		// hangman position
		int image_x = 370;
		int image_y = 140;
		// hanmgman size
		int image_sx = 230;
		int image_sy = 230;
		g.drawImage(i, image_x, image_y, image_sx, image_sy, this);

		if (hangmanCount >= 1) {

			if (hangmanCount >= 2) {

				i = t.getImage("images/hangman2.png");
			}

			if (hangmanCount >= 3) {

				i = t.getImage("images/hangman3.png");
			}
			if (hangmanCount >= 4) {
				// right arm
				i = t.getImage("images/hangman4.png");
			}
			if (hangmanCount >= 5) {
				// left foot
				i = t.getImage("images/hangman5.png");
			}
			if (hangmanCount >= 6) {
				// right foot
				i = t.getImage("images/hangman6.png");
			}
			if (hangmanCount >= 7) {
				// right foot
				i = t.getImage("images/hangman7.png");
			}

			g.drawImage(i, image_x, image_y, image_sx, image_sy, this);
		}

	}

	/**
	 * This method is called from within the constructor to initialize the form.
	 * WARNING: Do NOT modify this code. The content of this method is always
	 * regenerated by the Form Editor.
	 */
	private void initComponents() {

		jButton1 = new javax.swing.JButton();
		jButton2 = new javax.swing.JButton();
		jButton3 = new javax.swing.JButton();
		jButton4 = new javax.swing.JButton();
		jButton5 = new javax.swing.JButton();
		jButton6 = new javax.swing.JButton();
		jButton7 = new javax.swing.JButton();
		jButton8 = new javax.swing.JButton();
		jButton9 = new javax.swing.JButton();
		jButton10 = new javax.swing.JButton();
		jButton11 = new javax.swing.JButton();
		jButton12 = new javax.swing.JButton();
		jButton13 = new javax.swing.JButton();
		jButton14 = new javax.swing.JButton();
		jButton15 = new javax.swing.JButton();
		jButton16 = new javax.swing.JButton();
		jButton17 = new javax.swing.JButton();
		jButton18 = new javax.swing.JButton();
		jButton19 = new javax.swing.JButton();
		jButton20 = new javax.swing.JButton();
		jButton21 = new javax.swing.JButton();
		jButton22 = new javax.swing.JButton();
		jButton23 = new javax.swing.JButton();
		jButton24 = new javax.swing.JButton();
		jButton25 = new javax.swing.JButton();
		jButton26 = new javax.swing.JButton();
		jLabel1 = new javax.swing.JLabel();
		jLabel2 = new javax.swing.JLabel();
		jMenuBar1 = new javax.swing.JMenuBar();
		jMenu1 = new javax.swing.JMenu();
		jMenuItem1 = new javax.swing.JMenuItem();
		jMenuItem2 = new javax.swing.JMenuItem();
		jMenuItem3 = new javax.swing.JMenuItem();
		jMenuItem4 = new javax.swing.JMenuItem();
		jMenu2 = new javax.swing.JMenu();
		jMenuItem5 = new javax.swing.JMenuItem();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		setTitle("CS 212 Term Project - Hangman Game");

		jButton1.setText("A");
		jButton1.setName("buttonA");
		jButton1.setActionCommand("A");
		jButton1.addActionListener(this);

		jButton2.setText("B");
		jButton2.setActionCommand("B");
		jButton2.addActionListener(this);

		jButton3.setText("C");
		jButton3.setActionCommand("C");
		jButton3.addActionListener(this);

		jButton4.setText("D");
		jButton4.setActionCommand("D");
		jButton4.addActionListener(this);

		jButton5.setText("E");
		jButton5.setActionCommand("E");
		jButton5.addActionListener(this);

		jButton6.setText("F");
		jButton6.setActionCommand("F");
		jButton6.addActionListener(this);

		jButton7.setText("G");
		jButton7.setActionCommand("G");
		jButton7.addActionListener(this);

		jButton8.setText("H");
		jButton8.setActionCommand("H");
		jButton8.addActionListener(this);

		jButton9.setText("I");
		jButton9.setActionCommand("I");
		jButton9.addActionListener(this);

		jButton10.setText("J");
		jButton10.setActionCommand("J");
		jButton10.addActionListener(this);

		jButton11.setText("K");
		jButton11.setActionCommand("K");
		jButton11.addActionListener(this);

		jButton12.setText("L");
		jButton12.setActionCommand("L");
		jButton12.addActionListener(this);

		jButton13.setText("M");
		jButton13.setActionCommand("M");
		jButton13.addActionListener(this);

		jButton14.setText("N");
		jButton14.setActionCommand("N");
		jButton14.addActionListener(this);

		jButton15.setText("O");
		jButton15.setActionCommand("O");
		jButton15.addActionListener(this);

		jButton16.setText("P");
		jButton16.setActionCommand("P");
		jButton16.addActionListener(this);

		jButton17.setText("Q");
		jButton17.setActionCommand("Q");
		jButton17.addActionListener(this);

		jButton18.setText("R");
		jButton18.setActionCommand("R");
		jButton18.addActionListener(this);

		jButton19.setText("S");
		jButton19.setActionCommand("S");
		jButton19.addActionListener(this);

		jButton20.setText("T");
		jButton20.setActionCommand("T");
		jButton20.addActionListener(this);

		jButton21.setText("U");
		jButton21.setActionCommand("U");
		jButton21.addActionListener(this);

		jButton22.setText("V");
		jButton22.setActionCommand("V");
		jButton22.addActionListener(this);

		jButton23.setText("W");
		jButton23.setActionCommand("W");
		jButton23.addActionListener(this);

		jButton24.setText("X");
		jButton24.setActionCommand("X");
		jButton24.addActionListener(this);

		jButton25.setText("Y");
		jButton25.setActionCommand("Y");
		jButton25.addActionListener(this);

		jButton26.setText("Z");
		jButton26.setActionCommand("Z");
		jButton26.addActionListener(this);

		jMenu1.setText("File");

		jMenuItem1.setText("New Game");
		jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jMenuItem1ActionPerformed(evt);
			}
		});
		jMenu1.add(jMenuItem1);

		jMenuItem2.setText("Reset Game");
		jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jMenuItem2ActionPerformed(evt);
			}
		});
		jMenu1.add(jMenuItem2);

		jMenuItem3.setText("Score Game");
		jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jMenuItem3ActionPerformed(evt);
			}
		});
		jMenu1.add(jMenuItem3);

		jMenuItem4.setText("Quit");
		jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jMenuItem4ActionPerformed(evt);
			}
		});
		jMenu1.add(jMenuItem4);

		jMenuBar1.add(jMenu1);

		jMenu2.setText("Edit");

		jMenuItem5.setText("About");
		jMenuItem5.setName("menuAbout"); // NOI18N
		jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jMenuItem5ActionPerformed(evt);
			}
		});
		jMenu2.add(jMenuItem5);

		jMenuBar1.add(jMenu2);

		setJMenuBar(jMenuBar1);

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(layout
				.createSequentialGroup().addContainerGap()
				.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(layout
						.createSequentialGroup().addComponent(jButton14)
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(jButton15)
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addComponent(jButton16, javax.swing.GroupLayout.DEFAULT_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(jButton17)
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
						.addComponent(jButton18, javax.swing.GroupLayout.PREFERRED_SIZE, 43,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(jButton19)
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
						.addComponent(jButton20, javax.swing.GroupLayout.DEFAULT_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED).addComponent(jButton21)
						.addGap(18, 18, 18).addComponent(jButton22)
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
						.addComponent(jButton23, javax.swing.GroupLayout.PREFERRED_SIZE, 43,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addGap(13, 13, 13)
						.addComponent(jButton24, javax.swing.GroupLayout.PREFERRED_SIZE, 39,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addGap(23, 23, 23).addComponent(jButton25)
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(jButton26,
								javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE,
								Short.MAX_VALUE))
						.addGroup(layout.createSequentialGroup()
								.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
										.addGroup(layout.createSequentialGroup().addComponent(jButton1)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(jButton2)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(jButton3).addGap(13, 13, 13).addComponent(jButton4)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(jButton5)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
												.addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 45,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
												.addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 42,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(jButton8).addGap(18, 18, 18).addComponent(jButton9)
												.addGap(18, 18, 18)
												.addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 38,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addGap(18, 18, 18)
												.addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 40,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addGap(18, 18, 18).addComponent(jButton12)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(jButton13))
										.addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 151,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 204,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGap(0, 0, Short.MAX_VALUE)))
				.addContainerGap()));
		layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				javax.swing.GroupLayout.Alignment.TRAILING,
				layout.createSequentialGroup().addContainerGap(246, Short.MAX_VALUE)
						.addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 28,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addGap(18, 18, 18)
						.addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 26,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addGap(36, 36, 36)
						.addGroup(layout
								.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE).addComponent(jButton1)
								.addComponent(jButton2).addComponent(jButton3).addComponent(jButton4)
								.addComponent(jButton5).addComponent(jButton6).addComponent(jButton7)
								.addComponent(jButton8).addComponent(jButton9).addComponent(jButton10)
								.addComponent(jButton11).addComponent(jButton12).addComponent(jButton13))
						.addGap(18, 18, 18)
						.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(jButton15).addComponent(jButton16).addComponent(jButton17)
								.addComponent(jButton18).addComponent(jButton19).addComponent(jButton20)
								.addComponent(jButton21).addComponent(jButton22).addComponent(jButton23)
								.addComponent(jButton24).addComponent(jButton25).addComponent(jButton26)
								.addComponent(jButton14))
						.addContainerGap()));

		pack();
	}// </editor-fold>//GEN-END:initComponents

	private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_jMenuItem4ActionPerformed
		statusCount = 2;
		System.exit(-1);
		repaint();
	}// GEN-LAST:event_jMenuItem4ActionPerformed

	private void jMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_jMenuItem5ActionPerformed
		AboutFrame aboutFrame = new AboutFrame();
		aboutFrame.setLocationRelativeTo(null);
		aboutFrame.setVisible(true);
		repaint();
	}// GEN-LAST:event_jMenuItem5ActionPerformed

	private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_jMenuItem1ActionPerformed
		// once the user has pressed play, change state and call to play
		// method
		hangmanCount = 0;
		statusCount = 1; // playing state
		replayState = 0; // but not playing same game
		scoreSaveState = false;
		play();

		// guesses = new char[guesses.length];
		numGuesses = "";
		repaint();
	}// GEN-LAST:event_jMenuItem1ActionPerformed

	private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_jMenuItem2ActionPerformed
		scoreSaveState = false;
		statusCount = 1;
		hangmanCount = 0;
		replayState = 1;
		numGuesses = "";
		play();
		repaint();
	}// GEN-LAST:event_jMenuItem2ActionPerformed

	private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_jMenuItem3ActionPerformed
		ScoreBoardFrame scoreboard = new ScoreBoardFrame();
		scoreboard.setLocationRelativeTo(null);
		scoreboard.setVisible(true);
		repaint();
	}// GEN-LAST:event_jMenuItem3ActionPerformed

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		/* Set the Nimbus look and feel */
		// <editor-fold defaultstate="collapsed" desc=" Look and feel setting code
		// (optional) ">
		/*
		 * If Nimbus (introduced in Java SE 6) is not available, stay with the default
		 * look and feel. For details see
		 * http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
		 */
		try {
			for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())) {
					javax.swing.UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		} catch (ClassNotFoundException ex) {
			java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (InstantiationException ex) {
			java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (IllegalAccessException ex) {
			java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (javax.swing.UnsupportedLookAndFeelException ex) {
			java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		}
		// </editor-fold>

		/* Create and display the form */
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				MainFrame frame = new MainFrame();
				frame.setLocationRelativeTo(null);
				frame.setVisible(true);
			}
		});
	}

	// Variables declaration - do not modify//GEN-BEGIN:variables
	private javax.swing.JButton jButton1;
	private javax.swing.JButton jButton10;
	private javax.swing.JButton jButton11;
	private javax.swing.JButton jButton12;
	private javax.swing.JButton jButton13;
	private javax.swing.JButton jButton14;
	private javax.swing.JButton jButton15;
	private javax.swing.JButton jButton16;
	private javax.swing.JButton jButton17;
	private javax.swing.JButton jButton18;
	private javax.swing.JButton jButton19;
	private javax.swing.JButton jButton2;
	private javax.swing.JButton jButton20;
	private javax.swing.JButton jButton21;
	private javax.swing.JButton jButton22;
	private javax.swing.JButton jButton23;
	private javax.swing.JButton jButton24;
	private javax.swing.JButton jButton25;
	private javax.swing.JButton jButton26;
	private javax.swing.JButton jButton3;
	private javax.swing.JButton jButton4;
	private javax.swing.JButton jButton5;
	private javax.swing.JButton jButton6;
	private javax.swing.JButton jButton7;
	private javax.swing.JButton jButton8;
	private javax.swing.JButton jButton9;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JMenu jMenu1;
	private javax.swing.JMenu jMenu2;
	private javax.swing.JMenuBar jMenuBar1;
	private javax.swing.JMenuItem jMenuItem1;
	private javax.swing.JMenuItem jMenuItem2;
	private javax.swing.JMenuItem jMenuItem3;
	private javax.swing.JMenuItem jMenuItem4;
	private javax.swing.JMenuItem jMenuItem5;
	// End of variables declaration//GEN-END:variables

	@Override
	public void actionPerformed(ActionEvent e) {

		String command = e.getActionCommand();

		if (command.length() == 1 && statusCount == 1) {
			letterButtonPressed(command);
		}

		repaint();
	}

	// method receives actionevent from JButtons and compares it to randphrase
	// array
	public void letterButtonPressed(String command) {

		if (hangmanCount < 7 && counter > 0) {
			if (word.contains(command.toLowerCase())) {
				for (int i = 0; i < wordArr.length; i++) {
					if (command.toLowerCase().charAt(0) == wordArr[i]) {
						guessResults[i] = command.toLowerCase().charAt(0);
					}
				}
				// if letter does not match - bodycounter increases
			} else if (!word.contains(command.toLowerCase())) {
				hangmanCount++;
			}

			// concatenation user guesses
			numGuesses += command;
			if (hangmanCount < 7 && !checkWinState()) {
				numGuesses += ",";
			}
			repaint();
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}
}
