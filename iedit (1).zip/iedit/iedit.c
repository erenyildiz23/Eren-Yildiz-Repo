#include <stdio.h>
#include <stdlib.h>
#include "gfx.h"

struct pixel
{
  int red;
  int green;
  int blue;
};

struct pixel orig[128][128]; // original image (max. image size 128x128)
struct pixel eb[128][128];   // editing buffer

struct operation
{
  int op; // 1-copy/paste, 2-blur, 3-grayscale, 4-brighten
  int x;  // destination for copy/paste
  int y;
};

struct operation stack[100]; // max. 100 operations
struct operation *sptr;      // stack pointer
struct operation *max_sptr;  // maximum stack pointer for redo

// function prototypes
void edit(char *fileName);
void filter(int op, int x, int y);
void undo();
void redo();
void view();
void save(char *fileName);
void copy_paste(int x, int y);
void blur();
void grayscale();
void brighten();

int main(int argc, char *argv[])
{
  char command;
  char *fileName;
  int op, x, y;

  // initialize stack pointers
  sptr = stack;
  max_sptr = stack;

  // read in command and file name from user input
  printf("Enter command and file name: ");
  scanf("%c %s", &command, fileName);

  switch (command)
  {
  case 'E':
    edit(fileName);
    break;
  case 'F':
    printf("Enter operation and coordinates: ");
    scanf("%d %d %d", &op, &x, &y);
    filter(op, x, y);
    break;
  case 'U':
    undo();
    break;
  case 'R':
    redo();
    break;
  case 'V':
    view();
    break;
  case 'S':
    save(fileName);
    break;
  case 'X':
    return 0;
  default:
    printf("Invalid command.\n");
  }

  return 0;
}

void edit(char *fileName)
{
  // open the specified bitmap file
  FILE *fp = fopen(fileName, "r");
  if (fp == NULL)
  {
    printf("Error: file does not exist.\n");
    return;
  }

  // read the contents of the file into the original image and the editing buffer
  for (int i = 0; i < 128; i++)
  {
    for (int j = 0; j < 128; j++)
    {
      fscanf(fp, "%d %d %d", &orig[i][j].red, &orig[i][j].green, &orig[i][j].blue);
      eb[i][j] = orig[i][j];
    }
  }
  fclose(fp);

  // open a window on the screen
  int width = 512, height = 512;
  char *title = "Iedit";
  gfx_open(width, height, title);

  // copy the image to the viewing buffer and draw it on the screen
  for (int i = 0; i < 128; i++)
  {
    for (int j = 0; j < 128; j++)
    {
      gfx_color(eb[i][j].red, eb[i][j].green, eb[i][j].blue);
      gfx_point(i, j);
    }
  }

  // wait for the user to close the window
  while (1)
  {
    if (gfx_event_waiting())
    {
      char c = gfx_wait();
      if (c == 'q')
        break;
    }
  }
}
void save(char *fileName)
{
  // apply all filters stored on the stack to the image in the editing buffer
  for (struct operation *p = stack; p <= sptr; p++)
  {
    int op = p->op;
    int x = p->x;
    int y = p->y;
    switch (op)
    {
    case 1:
      copy_paste(x, y);
      break;
    case 2:
      blur();
      break;
    case 3:
      grayscale();
      break;
    case 4:
      brighten();
      break;
    default:
      printf("Invalid operation.\n");
    }
  }

  // open the specified file for writing
  FILE *fp = fopen(fileName, "w");
  if (fp == NULL)
  {
    printf("Error: could not open file for writing.\n");
    return;
  }

  // write the contents of the editing buffer to the file in the correct format
  for (int i = 0; i < 128; i++)
  {
    for (int j = 0; j < 128; j++)
    {
      fprintf(fp, "%d %d %d\n", eb[i][j].red, eb[i][j].green, eb[i][j].blue);
    }
  }

  // close the file
  fclose(fp);
}
void undo()
{
  // check if the stack is empty
  if (sptr <= stack)
    return;

  // decrement the stack pointer
  sptr--;
}

void redo()
{
  // check if the stack pointer exceeds the valid operations on the stack
  if (sptr >= max_sptr)
    return;

  // increment the stack pointer
  sptr++;
}
void copy_paste(int x, int y)
{
  // copy the top left part of the image from (0,0) to (20,20)
  for (int i = 0; i < 20; i++)
  {
    for (int j = 0; j < 20; j++)
    {
      eb[i][j] = orig[i][j];
    }
  }

  // paste the copied image starting from (x,y)
  for (int i = 0; i < 20; i++)
  {
    for (int j = 0; j < 20; j++)
    {
      eb[x + i][y + j] = eb[i][j];
    }
  }
}
void blur()
{
  // create a temporary buffer to store the blurred image
  struct pixel temp[128][128];

  // blur the image by setting the red, green, blue components of each pixel value to the average of its 4 neighbor pixels
  for (int i = 1; i < 127; i++)
  {
    for (int j = 1; j < 127; j++)
    {
      temp[i][j].red = (eb[i - 1][j].red + eb[i + 1][j].red + eb[i][j - 1].red + eb[i][j + 1].red) / 4;
      temp[i][j].green = (eb[i - 1][j].green + eb[i + 1][j].green + eb[i][j - 1].green + eb[i][j + 1].green) / 4;
      temp[i][j].blue = (eb[i - 1][j].blue + eb[i + 1][j].blue + eb[i][j - 1].blue + eb[i][j + 1].blue) / 4;
    }
  }

  // copy the blurred image from the temporary buffer back to the editing buffer
  for (int i = 0; i < 128; i++)
  {
    for (int j = 0; j < 128; j++)
    {
      eb[i][j] = temp[i][j];
    }
  }
}
void brighten()
{
  // change the brightness of the image by incrementing the red, green, blue components of each pixel
  for (int i = 0; i < 128; i++)
  {
    for (int j = 0; j < 128; j++)
    {
      eb[i][j].red = (eb[i][j].red + 10) % 256;
      eb[i][j].green = (eb[i][j].green + 10) % 256;
      eb[i][j].blue = (eb[i][j].blue + 10) % 256;
    }
  }
}
void view()
{
  // apply all filters stored on the stack to the image in the editing buffer
  for (struct operation *p = stack; p <= sptr; p++)
  {
    int op = p->op;
    int x = p->x;
    int y = p->y;
    switch (op)
    {
    case 1:
      copy_paste(x, y);
      break;
    case 2:
      blur();
      break;
    case 3:
      grayscale();
      break;
    case 4:
      brighten();
      break;
    default:
      printf("Invalid operation.\n");
    }
  }

  // display the contents of the editing buffer on the screen
  for (int i = 0; i < 128; i++)
  {
    for (int j = 0; j < 128; j++)
    {
      gfx_color(eb[i][j].red, eb[i][j].green, eb[i][j].blue);
      gfx_point(i, j);
    }
  }
}
void grayscale()
{
  // convert the image to grayscale by setting each pixel value to the average of its red, green, blue components
  for (int i = 0; i < 128; i++)
  {
    for (int j = 0; j < 128; j++)
    {
      int gray = (eb[i][j].red + eb[i][j].green + eb[i][j].blue) / 3;
      eb[i][j].red = gray;
      eb[i][j].green = gray;
      eb[i][j].blue = gray;
    }
  }
}

void filter(int op, int x, int y)
{
  // TODO: apply the specified operation on the image
  // (1 - copy/paste, 2 - blur, 3 - grayscale, 4 - brighten)
  switch (op)
  {
  case 1:
    copy_paste(x, y);
    break;
  case 2:
    blur();
    break;
  case 3:
    grayscale();
    break;
  case 4:
    brighten();
    break;
  default:
    printf("Invalid operation.\n");
  }
}
