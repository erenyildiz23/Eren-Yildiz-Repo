GLfloat flagAngle = 0.0f;
GLfloat flagSpeed = 50.0f; // 50 degrees per second
GLfloat dragonXPos = 0.0f;
GLfloat dragonSpeed = 1.0f; // 1 unit per second
glm::vec3 knightPos = glm::vec3(0.0f, 0.0f, 0.0f);
GLfloat knightSpeed = 2.0f; // 2 units per second


void updateFlagRotation(GLfloat deltaTime)
{
flagAngle += flagSpeed * deltaTime;
if (flagAngle > 360.0f)
{
flagAngle -= 360.0f;
}
}


glm::mat4 model;
model = glm::translate(model, glm::vec3(0.0f, 2.0f, 0.0f));
model = glm::rotate(model, glm::radians(flagAngle), glm::vec3(0.0f, 1.0f, 0.0f));


void updateDragonPosition(GLfloat deltaTime)
{
dragonXPos += dragonSpeed * deltaTime;
if (dragonXPos > 10.0f)
{
dragonXPos = -10.0f;
}
}


glm::mat4 model;
model = glm::translate(model, glm::vec3(dragonXPos, 0.0f, -5.0f));

void handleKnightMovement(GLFWwindow* window, int key, int scancode, int action, int mode)
{
if (key == GLFW_KEY_A)
{
knightPos -= glm::vec3(knightSpeed, 0.0f, 0.0f);
}

if (key == GLFW_KEY_D)
{
knightPos += glm::vec3(knightSpeed, 0.0f, 0.0f);
}

if (key == GLFW_KEY_W)
{
knightPos += glm::vec3(0.0f, 0.0f, -knightSpeed);
}

if (key == GLFW_KEY_S)
{
knightPos -= glm::vec3(0.0f, 0.0f, -knightSpeed);
}
}


glm::mat4 model;
model = glm::translate(model, knightPos);