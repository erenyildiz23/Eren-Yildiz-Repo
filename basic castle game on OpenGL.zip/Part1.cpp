// Declare camera position and orientation variables
glm::vec3 cameraPos = glm::vec3(0.0f, 0.0f, 3.0f);
glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);
GLfloat cameraSpeed = 0.1f;
GLfloat cameraYaw = -90.0f;
GLfloat cameraPitch = 0.0f;

// Handle user input for camera movement
void handleCameraMovement(GLFWwindow* window, int key, int scancode, int action, int mode)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
    {
        glfwSetWindowShouldClose(window, GL_TRUE);
    }

    if (key == GLFW_KEY_F)
    {
        cameraPos += cameraSpeed * cameraFront;
    }

    if (key == GLFW_KEY_B)
    {
        cameraPos -= cameraSpeed * cameraFront;
    }

    if (key == GLFW_KEY_T)
    {
        cameraYaw += 5.0f;
    }

    if (key == GLFW_KEY_1)
    {
        cameraYaw -= 5.0f;
    }

    glm::vec3 front;
    front.x = cos(glm::radians(cameraYaw)) * cos(glm::radians(cameraPitch));
    front.y = sin(glm::radians(cameraPitch));
    front.z = sin(glm::radians(cameraYaw)) * cos(glm::radians(cameraPitch));
    cameraFront = glm::normalize(front);
}

// Bind handleCameraMovement function to GLFW key events
glfwSetKeyCallback(window, handleCameraMovement);
