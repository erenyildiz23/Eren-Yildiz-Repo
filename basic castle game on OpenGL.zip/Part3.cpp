import pygame
from OpenGL.GL import *

# Load image file
image = pygame.image.load('princess.png')

# Generate a texture id
texture_id = glGenTextures(1)

# Tell OpenGL you are using this texture
glBindTexture(GL_TEXTURE_2D, texture_id)

# Set parameters
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)

# Create the texture
texture_data = pygame.image.tostring(image, 'RGB', True)
width, height = image.get_size()
glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, texture_data)

glMaterial(GL_FRONT, GL_AMBIENT, [1.0, 0.0, 0.0, 1.0])
glMaterial(GL_FRONT, GL_DIFFUSE, [1.0, 0.0, 0.0, 1.0])
glMaterial(GL_FRONT, GL_SPECULAR, [1.0, 1.0, 1.0, 1.0])
glMaterial(GL_FRONT, GL_SHININESS, 50.0)

# Enable lighting
glEnable(GL_LIGHTING)

# Enable light 0
glEnable(GL_LIGHT0)

# Set properties for light 0
glLightfv(GL_LIGHT0, GL_POSITION, [0, 0, 0, 1])
glLightfv(GL_LIGHT0, GL_DIFFUSE, [1.0, 1.0, 1.0, 1.0])
glLightfv(GL_LIGHT0, GL_SPECULAR, [1.0, 1.0, 1.0, 1.0])