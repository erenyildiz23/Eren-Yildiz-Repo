// Declare dragon position and speed variables
GLfloat dragonXPos = 0.0f;
GLfloat dragonSpeed = 1.0f; // 1 unit per second

// Update dragon position based on elapsed time
void updateDragonPosition(GLfloat deltaTime)
{
    dragonXPos += dragonSpeed * deltaTime;
    if (dragonXPos > 10.0f)
    {
        dragonXPos = -10.0f;
    }
}

// Apply dragon translation transformation to model matrix
glm::mat4 model;
model = glm::translate(model, glm::vec3(dragonXPos, 0.0f, -5.0f));