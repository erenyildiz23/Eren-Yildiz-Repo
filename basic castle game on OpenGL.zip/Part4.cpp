knight_position = [0, 0, 0]

while not glfw.window_should_close(window):
    if glfw.get_key(window, glfw.KEY_A) == glfw.PRESS:
        knight_position[0] -= 1  # move left
    if glfw.get_key(window, glfw.KEY_D) == glfw.PRESS:
        knight_position[0] += 1  # move right
    if glfw.get_key(window, glfw.KEY_W) == glfw.PRESS:
        knight_position[2] -= 1  # move forward
    if glfw.get_key(window, glfw.KEY_S) == glfw.PRESS:
        knight_position[2] += 1  # move backward