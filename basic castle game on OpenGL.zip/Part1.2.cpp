// Declare flag rotation angle and speed variables
GLfloat flagAngle = 0.0f;
GLfloat flagSpeed = 50.0f; // 50 degrees per second

// Update flag rotation angle based on elapsed time
void updateFlagRotation(GLfloat deltaTime)
{
    flagAngle += flagSpeed * deltaTime;
    if (flagAngle > 360.0f)
    {
        flagAngle -= 360.0f;
    }
}

// Apply flag rotation transformation to model matrix
glm::mat4 model;
model = glm::translate(model, glm::vec3(0.0f, 2.0f, 0.0f));
model = glm::rotate(model, glm::radians(flagAngle), glm::vec3(0.0f, 1.0f, 0.0f));
