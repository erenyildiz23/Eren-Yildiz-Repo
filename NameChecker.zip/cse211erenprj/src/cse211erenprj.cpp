#include <iostream>
#include "PersonList.h"

using namespace std;


int main() {
    PersonList personList;
    personList.loadFile("input.txt");

    printf("\nAfter input file loaded:\n");

    personList.printByName();
    personList.printByAge();

    personList.remove("elif");

    printf("\n-----------------------------------------\n");

    printf("\nafter \"elif\" removed:\n");

    personList.printByName();
    personList.printByAge();

    personList.update("deniz", 40);

    printf("\n-----------------------------------------\n");

    printf("\nafter \"deniz\" updated with age 40:\n");

    personList.printByName();
    personList.printByAge();

    personList.add("arda", 12);

    printf("\n-----------------------------------------\n");

    printf("\nafter \"arda\" added with age 12:\n");

    personList.printByName();
    personList.printByAge();

    printf("\n-----------------------------------------\n");

    personList.add("metin", 12);

    printf("\nafter \"metin\" added with age 12:\n");

    personList.printByName();
    personList.printByAge();

    printf("\n-----------------------------------------\n");

    personList.update("arda", 26);

    printf("\nafter \"arda\" updated with age 26:\n");

    personList.printByName();
    personList.printByAge();

    printf("\n-----------------------------------------\n");

    printf("\nResults saved to output files\n");

    personList.saveToFileByName("output_name.txt");
    personList.saveToFileByAge("output_age.txt");

	return 0;
}
