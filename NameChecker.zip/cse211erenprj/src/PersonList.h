#include <string>

using namespace std;

#ifndef PERSONLIST_H_
#define PERSONLIST_H_

typedef struct Person_t
{
	int age;
	string name;
    struct Person_t *nextptrAge;
    struct Person_t *nextptrName;

    Person_t(const string& name = "", const int& age = 0, Person_t* nextptrAge = nullptr, Person_t* nextptrName = nullptr) {
		this->name = name;
		this->age = age;
		this->nextptrAge = nextptrAge;
		this->nextptrName = nextptrName;
	}
} Person;

class PersonList
{
	public:
		PersonList();
		void add(string, int);
		bool remove(string);
		void update(string, int);
		void printByAge();
		void printByName();
		void loadFile(string);
		void saveToFileByAge(string);
		void saveToFileByName(string);

	private:
		void addByAge(string, int);
		void addByName(string, int);

		Person* headName;
		Person* headAge;
};


#endif /* PERSONLIST_H_ */
