#include "PersonList.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <string.h>

PersonList::PersonList() {
	headAge = nullptr;
	headName = nullptr;
}

void PersonList::add(string name, int age) {
	addByAge(name, age);
	addByName(name, age);
}

void PersonList::addByAge(string name, int age) {
	Person* newNode = new Person(name, age);

	if (headAge == nullptr)
	{
		headAge = newNode;
	}
	else if (newNode->age < headAge->age)
	{
		newNode->nextptrAge = headAge;
		headAge = newNode;
	}
	else
	{
		Person* current = headAge;

		while (current->nextptrAge != nullptr && (current->nextptrAge->age < newNode->age || current->nextptrAge->age == newNode->age))
		{
			current = current->nextptrAge;
		}

		newNode->nextptrAge = current->nextptrAge;
		current->nextptrAge = newNode;
	}
}

void PersonList::addByName(string name, int age) {
	Person* newNode = new Person(name, age);

	if (headName == nullptr)
	{
		headName = newNode;
	}
	else if (newNode->name.compare(headName->name) < 0)
	{
		newNode->nextptrName = headName;
		headName = newNode;
	}
	else
	{
		Person* current = headName;

		while (current->nextptrName != nullptr && (current->nextptrName->name.compare(newNode->name) < 0 || current->nextptrName->name.compare(newNode->name) == 0))
		{
			current = current->nextptrName;
		}

		newNode->nextptrName = current->nextptrName;
		current->nextptrName = newNode;
	}
}

void PersonList::loadFile(string inputFile) {
	std::ifstream infile(inputFile);

	std::string temp;
	std::string name;
	int age;

	while (std::getline(infile, temp)) {
	  istringstream ss(temp);
	  ss >> name>>age;
	  add(name, age);
	}
	infile.close();
}

void PersonList::printByName() {
	cout << "\nprintByName:" << endl;

	Person* current = headName;

	while (current != nullptr)
	{
		cout << current->age << " " << current->name << endl;
		current = current->nextptrName;
	}
}

void PersonList::printByAge() {
	cout << "\nprintByAge:" << endl;

	Person* current = headAge;

	while (current != nullptr)
	{
		cout << current->age << " " << current->name << endl;
		current = current->nextptrAge;
	}
}

bool PersonList::remove(string name) {
	Person* currentAge = headAge;
	bool result = false;

	if (currentAge == nullptr)
	{
		return false;
	}

	Person* currentName = headName;

	if (currentName == nullptr)
	{
		return false;
	}

	if (currentAge->name.compare(name) == 0)
	{
		headAge = headAge->nextptrAge;
		free(currentAge);
		result = true;
	}

	if (currentName->name.compare(name) == 0)
	{
		headName = headName->nextptrName;
		free(currentName);
		result = true;
	}

	Person* current = headName;

	while (current->nextptrName != nullptr && current->nextptrName->name.compare(name) != 0)
	{
		current = current->nextptrName;
	}

	if (current->nextptrName != NULL)
	{
		Person* temp = current->nextptrName;

		current->nextptrName = current->nextptrName -> nextptrName;
		free(temp);
		result = true;
	}

	// ----------------------------

	current = headAge;

	while (current->nextptrAge != nullptr && current->nextptrAge->name.compare(name) != 0)
	{
		current = current->nextptrAge;
	}

	if (current->nextptrAge != NULL)
	{
		Person* temp = current->nextptrAge;

		current->nextptrAge = current->nextptrAge -> nextptrAge;
		free(temp);
		result = true;
	}

	return result;
}

void PersonList::update(string name, int age) {
	if (remove(name) == true)
	{
		add(name, age);
	}
}

void PersonList:: saveToFileByAge(string outfilename)
{
	ofstream outfile(outfilename);

	if (outfile.is_open())
	{

		Person* current = headAge;

		while (current != nullptr)
		{
			outfile << current->name << " " << current->age << endl;
			current = current->nextptrAge;
		}

		outfile.close();
	}
}

void PersonList:: saveToFileByName(string outfilename)
{
	ofstream outfile(outfilename);

	if (outfile.is_open())
	{
		Person* current = headName;

		while (current != nullptr)
		{
			outfile << current->name << " " << current->age << endl;
			current = current->nextptrName;
		}
		outfile.close();
	}
}
