<html>
<body>

welcome:<?php echo $_POST["name"]; ?><br>
your username is:<?php echo $_POST["username"]; ?><br>
your password is: <?php echo $_POST["password"]; ?><br>
<?php
$baglan = mysqli_connect("localhost","root","mysql", "twit");

if(!$baglan)
{
		die("connection failed:".mysqli_connect_error());

}
else
{
	echo "connection successfull";
}


$ekle="INSERT INTO USERS (name,username , password) VALUES ('{$_POST['name']}', '{$_POST['username']}','{$_POST['password']}')";

$calistirekle = mysqli_query($baglan,$ekle);
if ($calistirekle) {
echo '<div class="alert alert-success" role="alert"> Kayıt Başarılı bir şekilde eklendi.
</div>';
}
else{
echo '<div class="alert alert-danger" role="alert"> Kayıt eklenirken bir problem oluştu.
</div>';
}


?>

</body>
</html>