<html>
<body>

Welcome <?php echo $_POST["username"]; ?><br>
your password is: <?php echo $_POST["password"]; ?><br>
<?php
$baglan = mysqli_connect("localhost","root","mysql", "twit");

if(!$baglan)
{
		die("connection failed:".mysqli_connect_error());

}
else
{
	echo "connection successfull";
}
$sUser=$_POST['username'];
    $sPass=$_POST['password'];
 $query="SELECT * From users where username='$sUser' and password='$sPass'";
    $result=mysqli_query($baglan,$query);
    if(mysqli_num_rows($result)==1)
    {
        session_start();
        $_SESSION['user_id']=$sUser;
        header('location:homepage.php');
    }
	else
	{
		echo "Authentication failed,invalid username or password";
	}
?>
</body>
</html>