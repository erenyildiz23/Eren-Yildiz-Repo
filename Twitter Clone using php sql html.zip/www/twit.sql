-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: localhost
-- Üretim Zamanı: 01 Haz 2023, 19:53:34
-- Sunucu sürümü: 8.0.31
-- PHP Sürümü: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `twit`
--

DELIMITER $$
--
-- Yordamlar
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `FetchFollowersTweets` (IN `input_username` VARCHAR(50))   BEGIN
    SELECT TWEETS.tweet_id, TWEETS.user_id, TWEETS.tweet_content, TWEETS.created_at, USERS.username
    FROM TWEETS
    INNER JOIN USERS ON TWEETS.user_id = USERS.user_id
    WHERE TWEETS.user_id IN (
        SELECT FOLLOWS.followed_id
        FROM FOLLOWS
        INNER JOIN USERS ON FOLLOWS.follower_id = USERS.user_id
        WHERE USERS.username = input_username
    )
    ORDER BY TWEETS.created_at DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `FetchTweetsForHomePage` (IN `userID` INT)   BEGIN
    SELECT TWEETS.tweet_id, TWEETS.user_id, TWEETS.tweet_content, TWEETS.created_at,USERS.username
    FROM TWEETS
    INNER JOIN FOLLOWS ON TWEETS.user_id = FOLLOWS.followed_id
    WHERE USERS.username = userID
    ORDER BY TWEETS.created_at DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GetTweetCount` (IN `p_username` VARCHAR(255), OUT `p_tweet_count` INT)   BEGIN
    SELECT COUNT(*) INTO p_tweet_count
    FROM tweets
    WHERE username = p_username;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SearchUserDetails` (IN `p_username` VARCHAR(255))   BEGIN
    SELECT user_id,name,username,password,creation_date,
	(SELECT COUNT(*) FROM follows WHERE follower_id = users.user_id) AS following_count,
    (SELECT COUNT(*) FROM follows WHERE followed_id = users.user_id) AS followed_count,
	(SELECT COUNT(*) FROM tweets WHERE user_id = users.user_id) AS tweet_count
    FROM users
    WHERE username = p_username;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SearchUserTweetDetails` (IN `userID` INT)   BEGIN
    SELECT * FROM tweets 
    WHERE user_id = userID;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `follows`
--

CREATE TABLE `follows` (
  `follower_id` int NOT NULL,
  `followed_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `follows`
--

INSERT INTO `follows` (`follower_id`, `followed_id`) VALUES
(2, 1),
(3, 1),
(1, 2),
(1, 3);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `tweets`
--

CREATE TABLE `tweets` (
  `tweet_id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `tweet_content` varchar(280) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `tweets`
--

INSERT INTO `tweets` (`tweet_id`, `user_id`, `tweet_content`, `created_at`) VALUES
(1, 1, 'test', '2023-05-25 20:25:53'),
(2, 2, 'merhaba', '2023-05-25 20:26:13'),
(3, 1, 'aa', '2023-05-25 21:43:46'),
(4, 2, 'bb', '2023-05-25 21:43:57'),
(5, 1, 'merhaba', '2023-05-29 21:06:21'),
(6, 1, 'ali koc istifa', '2023-05-29 21:06:36'),
(7, 1, 'merhaba', '2023-05-29 21:07:06'),
(8, 1, 'serce', '2023-06-01 19:25:35'),
(9, 3, 'vakıfbank', '2023-06-01 19:26:51');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users`
--

CREATE TABLE `users` (
  `user_id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `creation_date` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `users`
--

INSERT INTO `users` (`user_id`, `name`, `username`, `password`, `creation_date`) VALUES
(1, 'eren', 'eren1', 'were', '2023-05-29 22:19:33'),
(2, 'eren3', 'eren212', 'emre', '2023-05-29 22:19:33'),
(3, 'osman', 'osman123', '345', '2023-05-30 00:07:39');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `follows`
--
ALTER TABLE `follows`
  ADD PRIMARY KEY (`follower_id`,`followed_id`),
  ADD KEY `followed_id` (`followed_id`);

--
-- Tablo için indeksler `tweets`
--
ALTER TABLE `tweets`
  ADD PRIMARY KEY (`tweet_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Tablo için indeksler `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `tweets`
--
ALTER TABLE `tweets`
  MODIFY `tweet_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Tablo için AUTO_INCREMENT değeri `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Dökümü yapılmış tablolar için kısıtlamalar
--

--
-- Tablo kısıtlamaları `follows`
--
ALTER TABLE `follows`
  ADD CONSTRAINT `follows_ibfk_1` FOREIGN KEY (`follower_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `follows_ibfk_2` FOREIGN KEY (`followed_id`) REFERENCES `users` (`user_id`);

--
-- Tablo kısıtlamaları `tweets`
--
ALTER TABLE `tweets`
  ADD CONSTRAINT `tweets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
