<?php


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $follow_user_id = $_POST['follow_user_id'];

    echo $follow_user_id;
	session_start();

	// Get the user_id from the session
	$user_id = $_SESSION["user_id"];
	$follow_idx=0;
	$user_idx=0;
	try {
    // Create new PDO object and connect to the database.
    $pdo = new PDO('mysql:host=localhost;dbname=twit', 'root', 'mysql');


    // Prepare the CALL statement.
    $stmt = $pdo->prepare('CALL SearchUserDetails(?)');

    // Bind the user_id to the statement.
    $stmt->bindParam(1, $follow_user_id, PDO::PARAM_STR);

    // Execute the statement.
    $stmt->execute();

    // Fetch all of the remaining rows in the result set.
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
	?>
	
	<?php
    // Create a HTML table
	
    foreach ($result as $row) {
		$follow_idx=$row['user_id'];
		
       
    }
   
}
catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
try {
    // Create new PDO object and connect to the database.
    $pdo = new PDO('mysql:host=localhost;dbname=twit', 'root', 'mysql');


    // Prepare the CALL statement.
    $stmt = $pdo->prepare('CALL SearchUserDetails(?)');

    // Bind the user_id to the statement.
    $stmt->bindParam(1, $user_id, PDO::PARAM_STR);

    // Execute the statement.
    $stmt->execute();

    // Fetch all of the remaining rows in the result set.
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
	?>
	
	<?php
    // Create a HTML table
	
    foreach ($result as $row) {
		$user_idx=$row['user_id'];
		
       
    }
   
}
catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
	$stmt = $pdo->prepare("INSERT INTO follows (follower_id, followed_id) VALUES (?, ?)");
    $stmt->bindParam(1, $user_idx, PDO::PARAM_INT);
    $stmt->bindParam(2, $follow_idx, PDO::PARAM_INT);

    // Set the user ID
    

    // Execute the statement
    if ($stmt->execute()) {
        // Tweet inserted successfully
        echo "Followed Successfully!";
    } else {
        // Error occurred while inserting the tweet
        echo "follow failed";
    }
}


?>
