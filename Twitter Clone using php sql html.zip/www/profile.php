<html>
<body>
<?php
// Start the session
session_start();

// Get the user_id from the session
$user_id = $_SESSION["user_id"];

// Now you can use $user_id variable

 $pdo = new PDO('mysql:host=localhost;dbname=twit', 'root', 'mysql');

    // The ID of the user for whom to fetch the home page tweets.
    $username = $user_id; // replace with actual user_id

    // Prepare the CALL statement.
    $stmt = $pdo->prepare('CALL SearchUserDetails(?)');

    // Bind the user_id to the statement.
    $stmt->bindParam(1, $username, PDO::PARAM_STR);

    // Execute the statement.
    $stmt->execute();

    // Fetch all of the remaining rows in the result set.
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
	$user_id = 0;
	foreach ($result as $row) {
       
    
        echo '<br><b>Welcome: </b>' . htmlspecialchars($row['name'], ENT_QUOTES) . '<br>';
		echo '<br><b>Username: </b>' . htmlspecialchars($row['username'], ENT_QUOTES) . '<br>';
		echo '<br><b>Tweets: </b>' . htmlspecialchars($row['tweet_count'], ENT_QUOTES) . '<br>';
		echo '<br><b>Followers: </b>' . htmlspecialchars($row['following_count'], ENT_QUOTES) . '<br>';
		echo '<br><b>Following: </b>' . htmlspecialchars($row['followed_count'], ENT_QUOTES) . '<br>';
		
		
		echo '<br><b>Creation date: </b>' . htmlspecialchars($row['creation_date'], ENT_QUOTES) . '<br>';
		
        $user_id=$row['user_id'];
		
    }
	// The ID of the user for whom to fetch the home page tweets.
	
   
	
?>
<?php


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $follow_user_id = $_POST['follow_user_id'];

    echo $follow_user_id;
}
	echo '<br>';
?>
<!-- Tweet form -->
<form method="get" action="profile.php">
    <textarea name="tweet_content" placeholder="Write a tweet"></textarea>
    <input type="submit" value="Tweet">
</form>
<?php
// Check if the form data has been submitted
if (isset($_GET['tweet_content'])) {
    // Get the search query
    $tweet_content = $_GET['tweet_content'];

    // Escape the query for safety
    $tweet_content = htmlspecialchars($tweet_content);
	 $stmt = $pdo->prepare("INSERT INTO tweets (user_id, tweet_content) VALUES (?, ?)");
    $stmt->bindParam(1, $user_id, PDO::PARAM_INT);
    $stmt->bindParam(2, $tweet_content, PDO::PARAM_STR);

    // Set the user ID
    

    // Execute the statement
    if ($stmt->execute()) {
        // Tweet inserted successfully
        echo "Tweet posted successfully!";
    } else {
        // Error occurred while inserting the tweet
        echo "Error posting tweet. Please try again.";
    }
}
?>
<?php
// Prepare the CALL statement.
    $stmt = $pdo->prepare('CALL SearchUserTweetDetails(?)');

    // Bind the user_id to the statement.
    $stmt->bindParam(1, $user_id,  PDO::PARAM_INT);

    // Execute the statement.
    $stmt->execute();

    // Fetch all of the remaining rows in the result set.
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
	$user_id = 0;
	echo '<br><b>Your Tweets: </b><br><br>';
	foreach ($result as $row) {
       
    
		echo "<b>Content:</b> " . $row['tweet_content'] . "<br>";
		echo "<b>Creation at:</b> " . $row['created_at'] . "<br>";
		// Display other columns as needed
		echo "<br>";
		
    }
?>
<br>
<table>
  <tr>
    <td><form action="homepage.php" method="get">
   
    <input type="submit" value="Homepage" />
</form></td>
    <td><form action="logout.php" method="get">
   
    <input type="submit" value="Logout" />
</form></td>
  </tr>
</table>
</body>
</html>