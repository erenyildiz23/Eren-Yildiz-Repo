<html>
<body>

<?php
// Start the session
session_start();

// Get the user_id from the session
$user_id = $_SESSION["user_id"];

// Now you can use $user_id variable
echo "@: " . $user_id;

?>

<form action="homepage.php" method="get">
    <input type="text" name="query" />
    <input type="submit" value="Search" />
</form>
<?php
// Check if the form data has been submitted
if (isset($_GET['query'])) {
    // Get the search query
    $query = $_GET['query'];

    // Escape the query for safety
    $query = htmlspecialchars($query);

    // Now you can use $query to search your database, for example
    //echo "You searched for: " . $query;
	try {
    // Create new PDO object and connect to the database.
    $pdo = new PDO('mysql:host=localhost;dbname=twit', 'root', 'mysql');

    // The ID of the user for whom to fetch the home page tweets.
    $username = $query; // replace with actual user_id

    // Prepare the CALL statement.
    $stmt = $pdo->prepare('CALL SearchUserDetails(?)');

    // Bind the user_id to the statement.
    $stmt->bindParam(1, $username, PDO::PARAM_STR);

    // Execute the statement.
    $stmt->execute();

    // Fetch all of the remaining rows in the result set.
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
	?>
	<br> <b> Search Results: </b> <br>
	<?php
    // Create a HTML table
   
    foreach ($result as $row) {
       
        echo '<br><b>Username: </b>' . htmlspecialchars($row['username'], ENT_QUOTES) . '<br>';
        echo '<br><b>Full Name: </b>' . htmlspecialchars($row['name'], ENT_QUOTES) . '<br>';
        
        echo '<form action="follow.php" method="post">
                <input type="hidden" name="follow_user_id" value="' . $row['username'] . '">
                <input type="submit" value="Follow">
              </form>';
    }
   
}
catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
}
?>
<br> <b> Tweets from the Users You Follow: </b> <br>
<?php
$pdo = new PDO('mysql:host=localhost;dbname=twit', 'root', 'mysql');
$stmt = $pdo->prepare('CALL FetchFollowersTweets(?)');
$stmt->execute([$_SESSION['user_id']]);
$tweets = $stmt->fetchAll();

// Display the tweets
foreach ($tweets as $row) {
    //echo "<br>".$tweet['tweet_content']."<br>";
	echo '<br><b>@</b>' . htmlspecialchars($row['username'], ENT_QUOTES) . '<br>';
    echo '<br><b>Content:</b>' . htmlspecialchars($row['tweet_content'], ENT_QUOTES) . '<br>';
    echo '<br><b>Created at:</b>' . htmlspecialchars($row['created_at'], ENT_QUOTES) . '<br>';
}

?>
<br>
<table>
  <tr>
    <td><form action="profile.php" method="get">
   
    <input type="submit" value="Profile" />
</form></td>
    <td><form action="logout.php" method="get">
   
    <input type="submit" value="Logout" />
</form></td>
  </tr>
</table>



</body>
</html>