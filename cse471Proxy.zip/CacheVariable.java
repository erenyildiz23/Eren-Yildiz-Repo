


public class CacheVariable {
	
    private String lastModified;
    private byte[] resource;

	public CacheVariable(String last_modified , byte[] resource ){
		this.lastModified = last_modified;
		this.resource = resource;
		
	}
	public String getLastModified() {
		return lastModified;
	}
	public byte[] getResource() {
		return resource;
	}

	@Override
	public String toString() {
		return "Last Modified: "+ getLastModified();
	}
	
	
	
}