
public class Response {
    private int statusCode;
    private String reasonPhrase;
    private MimeHeader mh;


    public Response(int code, String reason, MimeHeader m) {
        statusCode = code;
        reasonPhrase = reason;
        mh = m;
        mh.put("Connection", "close");
    }
    
    @Override
    public String toString() {
        return "HTTP/1.1 " + statusCode + " " + reasonPhrase + "\r\n" + mh + "\r\n";
    }
}