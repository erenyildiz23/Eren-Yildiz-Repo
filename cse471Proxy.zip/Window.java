import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;


public class Window extends JFrame implements ActionListener, Runnable{
	int WIDTH = 800;
	int HEIGHT = 600;
	public Window(Proxy proxy)
	{
		setTitle("Proxy");
		setMaximumSize(new Dimension(WIDTH,HEIGHT));
	    setMinimumSize(new Dimension(WIDTH,HEIGHT));
	    setResizable(false);
	    setLocationRelativeTo(null);
	    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	
	    add(proxy);
	    run();
	}
	
	public void createMenu() {
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);

		JMenu file = new JMenu("File");
		menuBar.add(file);
		
			JMenuItem start = new JMenuItem("Start");
			file.add(start);
			start.addActionListener((e) -> {
				Proxy.running = true;
				getContentPane().removeAll();
				JLabel label = new JLabel("Proxy Server is Running...", SwingConstants.CENTER);
				label.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 22));
				add(label);
				revalidate();
				repaint();
			});

			JMenuItem stop = new JMenuItem("Stop");
			file.add(stop);
			stop.addActionListener((e) -> {
				Proxy.running = false;
				getContentPane().removeAll();
				JLabel labelM = new JLabel("Proxy Server stopped...", SwingConstants.CENTER);
				labelM.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 22));
				add(labelM);
				revalidate();
				repaint();
			});
			
			JMenuItem report = new JMenuItem("Report");
			file.add(report);
			report.addActionListener(this);
			
			JMenuItem filter = new JMenuItem("Add host to filter");
			file.add(filter);
			filter.addActionListener((e) -> {
				String host = JOptionPane.showInputDialog("Add host to filter");
				Proxy.forbiddenAddresses.add(host);
				getContentPane().removeAll();
				JList list = new JList(Proxy.forbiddenAddresses.toArray());
				add(list);
				revalidate();
				repaint();
			});
			
			JMenuItem display_filter = new JMenuItem("Display current filtered hosts");
			file.add(display_filter);
			display_filter.addActionListener((e) -> {
				getContentPane().removeAll();
				JList list = new JList(Proxy.forbiddenAddresses.toArray());
				add(list);
				revalidate();
				repaint();
			});
			
			JMenuItem exit = new JMenuItem("Exit");
			file.add(exit);
			exit.setActionCommand("Exit");
			exit.addActionListener(this);
		
		JMenu help = new JMenu("Help");
		menuBar.add(help);
		help.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				// Display developer information in pop-up menu
				JOptionPane.showMessageDialog(null, "Transparent Proxy GUI\nDeveloped by [Developer Name]");
			}
		});

	} 

	@Override
	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();
		if(command.equals("Exit")) System.exit(0);
		
	}

	@Override
	public void run() {
	    createMenu();
	    setVisible(true);
	}
}
