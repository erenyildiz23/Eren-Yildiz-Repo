import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;


public class ServerHandler implements Runnable{
	
	private DataInputStream inFromClient;
	private DataOutputStream outToClient;
	private String host,path;
	private Thread thread;

	private int port_number = 80;
	public ServerHandler(Socket s) 
	{
		try {
			if(Proxy.running) {
				
				inFromClient = new DataInputStream(s.getInputStream());
				outToClient = new DataOutputStream(s.getOutputStream());
				System.out.println("HOST:"+this.host);
				thread = new Thread(this);
				thread.start();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public String getRequestHeader(DataInputStream in ) throws NumberFormatException, IOException 
	{
		byte[] header = new byte[1024];

		int data;
		int h = 0;
		
		int content_length =-1;
		
		while ((data = in.read()) != -1) {
			header[h++] = (byte) data;
			
			
			if(content_length == 0 ) { break;}
			content_length = (content_length > 0)? content_length - 1 : content_length;
			
			if ( header[h - 1] == '\n' && header[h - 2] == '\r' && header[h - 3] == '\n' && header[h - 4] == '\r') {
				if(header[0] == 'P') {
					
					String s = new String(header, 0, h);
					
					try {
					int content_length_index = s.indexOf("Content-Length:");
					content_length = Integer.parseInt(s.substring(content_length_index+16,s.indexOf("\r\n",content_length_index)))-1;
					//System.out.println("Content _Length is: "+content_length);
					}
					catch(StringIndexOutOfBoundsException e) {
						System.out.println("No Content Length found");
						System.out.println(s);
					}
					catch(NumberFormatException nfe) 
					{
						int content_length_index = s.indexOf("Content-Length:");
						System.out.println(s.substring(content_length_index+16,s.indexOf("\r\n",content_length_index)-2));
					}
					
					
					continue;
					}
				
				break;
			}
		}
		
		return new String(header, 0, h);
	}
	
	
	
	
	public String createErrorPage(int code, String msg, String address) 
	{
		String html_page = "";
		html_page += "<html>\r\n" + "<body>\r\n" + "<h1>"+code+" "+ msg + "</h1>\r\n" + "</body>\r\n" + "</html>\r\n";
		MimeHeader mh = MimeHeader.makeMimeHeader("text/html", html_page.length());
		Response hr = new Response(code,msg,mh); 
		
		return hr + html_page;
	}

	private void handleHeadHeader( MimeHeader requestMimeHeader) throws IOException {
		requestMimeHeader.put("User-Agent", requestMimeHeader.get("User-Agent") + "+ 471PROXY");

		Socket sSocket = new Socket(host, port_number);
		DataInputStream inFromServer = new DataInputStream(sSocket.getInputStream());
		DataOutputStream outToServer = new DataOutputStream(sSocket.getOutputStream());
		ByteArrayOutputStream bAOS = new ByteArrayOutputStream(10000);
		int temp;
		byte[] buffer = new byte[1024];
		byte[] response;
		String raw_Response,responseHeader;

		new ServerProxy(inFromClient , outToServer);
		outToServer.writeBytes("HEAD "+ path +" HTTP/1.1\r\n" + requestMimeHeader + "\r\n");


		while ((temp = inFromServer.read(buffer)) != -1) bAOS.write(buffer, 0, temp);
		response = bAOS.toByteArray();
		raw_Response = new String(response);
		responseHeader = raw_Response.substring(0, raw_Response.indexOf("\r\n\r\n"));
		outToClient.write(response);
		outToClient.close();
		sSocket.close();
	}

	private void handleConnectHeader( MimeHeader requestMimeHeader) throws IOException {
		requestMimeHeader.put("User-Agent", requestMimeHeader.get("User-Agent") + "+ 471PROXY");
		Socket sSocket = new Socket(host, port_number);
		DataInputStream inFromServer = new DataInputStream(sSocket.getInputStream());
		DataOutputStream outToServer = new DataOutputStream(sSocket.getOutputStream());
		int temp;
		byte[] buffer = new byte[1024];

		new ServerProxy(inFromClient , outToServer);

		String s = "HTTP/1.0 200 Connection established\r\n" + "Proxy-Agent: 471PROXY \r\n" + "\r\n";

		outToClient.write(s.getBytes());
		outToClient.flush();

		do {
			temp = ServerProxy.getReadings(buffer, inFromServer, outToClient);
		} while (temp >= 0);

		if(sSocket != null) sSocket.close();
	}
	private void handlePostHeader(MimeHeader requestMimeHeader) throws IOException {
		requestMimeHeader.put("User-Agent", requestMimeHeader.get("User-Agent") + "+ 471PROXY");

		Socket sSocket = new Socket(host, port_number);
		DataInputStream inFromServer = new DataInputStream(sSocket.getInputStream());
		DataOutputStream outToServer = new DataOutputStream(sSocket.getOutputStream());
		ByteArrayOutputStream bAOS = new ByteArrayOutputStream(10000);
		int temp;
		byte[] buffer = new byte[1024];
		byte[] response;
		String raw_Response,responseHeader;
		outToServer.writeBytes("POST "+ path +" HTTP/1.1\r\n" + requestMimeHeader + "\r\n" + requestMimeHeader.get("data"));
		while ((temp = inFromServer.read(buffer)) != -1) bAOS.write(buffer, 0, temp);

		response = bAOS.toByteArray();


		outToClient.write(response);
		outToClient.close();
		sSocket.close();
	}
	
	private void handleGetHeader( MimeHeader requestMimeHeader) throws IOException //Handle Proxy
	{
		//printer.add("\r\nInitiating the server connection");
		requestMimeHeader.put("User-Agent", requestMimeHeader.get("User-Agent") + " via CSE471 Proxy");
		
		Socket sSocket = new Socket(host, port_number);
		DataInputStream inFromServer = new DataInputStream(sSocket.getInputStream());
		DataOutputStream outToServer = new DataOutputStream(sSocket.getOutputStream());
		ByteArrayOutputStream bAOS = new ByteArrayOutputStream(10000);
		int temp;
		byte[] buffer = new byte[1024];
		byte[] response;
		String raw_Response,responseHeader;
		if( Cache.checkCache(host+path)) {
			try {
				outToServer.writeBytes("HEAD " + path + " HTTP/1.1\r\n" + requestMimeHeader+"If-Modified-Since: " +
						Cache.getCachedObjects(host+path).getLastModified()+"\r\n"+"\r\n");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}



			byte[] cache_buffer = new byte[2048];

			int a = 0;
			ByteArrayOutputStream cache_bAOS = new ByteArrayOutputStream(10000);
			while ((a = inFromServer.read(cache_buffer)) != -1) {
				cache_bAOS.write(cache_buffer, 0, a);
			}
			byte[] last_modified_response = cache_bAOS.toByteArray();


			if(new String(last_modified_response).contains("304")) {//Not modified

				byte[] cached_data = null;
				try {
					cached_data = Cache.getCachedObjects(host+path).getResource();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}


				outToClient.write(cached_data);
				System.out.println("Ben var kullanmak cache"+ "\r\n"); //Degistir!!!!

				outToClient.close();
				sSocket.close();
				return;
			}
			Cache.deleteObject(host+path);

		}
		outToServer.writeBytes("GET " + path + " HTTP/1.1\r\n" + requestMimeHeader + "\r\n");


		while ((temp = inFromServer.read(buffer)) != -1) bAOS.write(buffer, 0, temp);
		response = bAOS.toByteArray();
		raw_Response = new String(response);
		responseHeader = raw_Response.substring(0, raw_Response.indexOf("\r\n\r\n"));

		if(responseHeader.contains("Last-Modified:") && !Cache.checkCache(host+path)) {

			int last_modified_index = responseHeader.indexOf("Last-Modified:");

			Cache.addtoCache(host+path, responseHeader.substring(last_modified_index+15,responseHeader.indexOf("\n",last_modified_index) )  ,
					response);

		}


		outToClient.write(response);
		outToClient.close();
		sSocket.close();
		}
	
	@Override
	public void run() {
		try {
			String header = getRequestHeader(inFromClient);
			
			int initial = header.indexOf(" ");
			int next_space = header.indexOf(" ",initial+1);
			int endl = header.indexOf('\r');
			
			String reqHeaderRemainingLines = header.substring(endl + 2);
			MimeHeader requestMimeHeader = new MimeHeader(reqHeaderRemainingLines);
			String url = header.substring(initial + 1, next_space);
			
			String method = header.substring(0, initial);
			host = requestMimeHeader.get("Host");
			requestMimeHeader.put("Connection", "close");
			
			if(!method.equalsIgnoreCase("connect")) { path = url.substring(7); path = "/" + path.substring(path.indexOf("/")+1); }
			
			if (Proxy.forbiddenAddresses.contains(host)) {
				outToClient.writeBytes(createErrorPage(401, "Not Authorized", method));	
				return;
			} 

			switch(method.toLowerCase()) {
				case "get":

					handleGetHeader(requestMimeHeader);
					break;
				case "post":
					handlePostHeader(requestMimeHeader);
					break;
				case "head":
					handleHeadHeader(requestMimeHeader);
					break;
				case "connect":
					
					url = url.substring(0,url.indexOf(":"));
					
					path = url.substring(7);
					path = "/" + path.substring(path.indexOf("/")+1);
					
					host = url;
					port_number = 443;
					handleConnectHeader(requestMimeHeader);
					break;
				default:
					outToClient.writeBytes(createErrorPage(405, "Method Not Allowed", method));	
			}
			
		} catch (NumberFormatException | IOException e) {
			e.printStackTrace();
		}
	}

}
