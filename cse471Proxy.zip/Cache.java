
import java.util.HashMap;


public class Cache {
	private static HashMap<String, CacheVariable> cachedObjects = new HashMap<String, CacheVariable>();

	public synchronized static CacheVariable getCachedObjects(String URL) throws Exception {
		return cachedObjects.get(URL);
	}
	
	public synchronized static boolean addtoCache(String URL, String last_modified, byte[] resource) {
		if(cachedObjects.size() < 256)
			cachedObjects.put(URL, new CacheVariable(last_modified,resource));
		else 
			return false;
		
		return true;
	}
	public synchronized static boolean checkCache(String URL) {
		if(cachedObjects.containsKey(URL)) {
			return true;
		}
		
		return false;
		
	}
	public synchronized static boolean deleteObject(String URL) {
		if(cachedObjects.remove(URL) != null) return true;
		else return false;
		
	}
	
}