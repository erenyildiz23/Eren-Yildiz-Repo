import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.LinkedList;

import javax.swing.JLabel;




public class Proxy extends JLabel{
	public static LinkedList<String> forbiddenAddresses;
	public static Cache cache;
	public Thread thread;
	public ServerSocket welcomeSocket = null;
	public static boolean running = false;
	public Proxy() throws IOException {
		new Window(this);
		forbiddenAddresses = new LinkedList<String>();
		cache = new Cache();
		start();
	}
	
	public void start() {
		running = true;
		thread = new Thread(() -> {
			try {
				welcomeSocket = new ServerSocket(8080);
			} catch (IOException e) {
				e.printStackTrace();
			}
			while (true) {
				Socket connectionSocket = null;
				while(!running) {System.out.print("");}
				try {
					connectionSocket = welcomeSocket.accept();
				} catch (IOException e) {
				}
				new ServerHandler(connectionSocket);
			}
		});
		thread.start();
	}
	
	
	public static void main(String args[]) throws Exception
	{
		new Proxy();
	}
}

