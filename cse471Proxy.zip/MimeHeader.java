import java.text.SimpleDateFormat;
import java.util.*;


public class MimeHeader extends HashMap<String,String>{
	
	public MimeHeader() {
	}
	
	public MimeHeader(String data) {
		StringTokenizer st = new StringTokenizer(data, "\r\n");
		while (st.hasMoreTokens()) {
			String s = st.nextToken();
			try {
				int a = s.indexOf(":");
				String key = s.substring(0 , a);
				String value = s.substring(a+2);
				put(key, value);
			}catch(StringIndexOutOfBoundsException itr) {
				String key = "data";
				String value = s;
				put(key, value);
			}catch(Exception itr) {
				itr.printStackTrace();
			}
			
		}
	}
	
	@Override
	public String toString() {
		String str = "";
		Iterator<String> itr = keySet().iterator();
		while (itr.hasNext()) {
			String key = itr.next();
			if(key != "data"){
				String val = get(key);
				str += key + ": " + val + "\r\n";
			}
		}
		return str;
	}
	public static MimeHeader makeMimeHeader(String type, int length)
	{
		MimeHeader mh = new MimeHeader();
		Date d = new Date();
		TimeZone gmt = TimeZone.getTimeZone("GMT");
		SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy hh:mm:ss zzz");
		sdf.setTimeZone(gmt);
		String sdf_date = sdf.format(d);

		mh.put("Date",sdf_date);
		mh.put("Server","CSE-471" );
		mh.put("Content-type", type);

		if (length >= 0)
			mh.put("Content-Length", String.valueOf(length));
		return mh;
	}
}
